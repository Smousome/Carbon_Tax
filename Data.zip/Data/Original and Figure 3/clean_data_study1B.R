read.csv(here::here("E:/Summer 2023/4. Impact Evaluation in Environmental Economics Using Field Experiments/Data/S2/study1B_raw.csv"),
               stringsAsFactors = F)[-1, -c(1:6)] %>%
  dplyr::filter(V10 == 1) %>%
  dplyr::select(-dplyr::contains("consent"),
                -dplyr::contains("comments"),
                -dplyr::contains("intro"),
                -Q26, -Q28, -V10) %>%
  dplyr::mutate_all(dplyr::funs(as.numeric)) %>%
  dplyr::mutate(male = ifelse(gender == 1, 1, 0),
                implement_tax = ifelse(implement_tax == 1, "Tax",
                                       ifelse(implement_tax == 2, "No Tax", NA)),
                implement_taxnudge = ifelse(implement_taxnudge == 1, "Tax",
                                            ifelse(implement_taxnudge == 2,
                                                   "Nudge",
                                                   ifelse(implement_taxnudge == 3,
                                                          "Both",
                                                          ifelse(implement_taxnudge == 4,
                                                                 "Neither", NA)      ))),
                tax = ifelse(!is.na(implement_tax), implement_tax, implement_taxnudge),
                condition = ifelse(policy_only == 1,
                                   "Tax Only",
                                   "Tax + Nudge"),
                condition = factor(condition,
                                   levels = c("Tax Only", "Tax + Nudge")),
                pain = ifelse(high_pain == 1, "High Pain", "Low Pain"),
                pain = factor(pain,
                              levels = c("Low Pain", "High Pain")),
                support_tax = ifelse(tax %in% c("Tax", "Both"), 1, 0),
                support_nudge = ifelse(tax %in% c("Nudge", "Both"), 1, 0)) %>%
  dplyr::select(-dplyr::contains("implement"),
                -gender, -policy_only, -high_pain) %>%
  saveRDS(here::here("E:/Summer 2023/4. Impact Evaluation in Environmental Economics Using Field Experiments/Data/S2/study1B.Rds"))
