read.csv(here::here("E:/Summer 2023/4. Impact Evaluation in Environmental Economics Using Field Experiments/Data/S2/study3A_raw.csv"),
               stringsAsFactors = F)[-1,-c(1:6)] %>%
  dplyr::filter(V10 == 1) %>%
  dplyr::select(-dplyr::contains("comments"),
                -dplyr::contains("intro"),
                -dplyr::contains("des"),
                -dplyr::contains("Location"),
                -V10) %>%
  dplyr::mutate_at(dplyr::vars(-domain),
                    dplyr::funs(as.numeric)) %>%
  dplyr::mutate(male = ifelse(gender == 4, 1, 0)) %>%
  dplyr::select(-gender) %>%
  dplyr::mutate(implement_tax = ifelse(implement_tax == 1, "Tax",
                                        ifelse(implement_tax == 2, "NoTax", NA)),
                implement_nudge = ifelse(implement_nudge == 1, "Nudge",
                                         ifelse(implement_nudge == 2, "NoNudge", NA)),
                implement_taxnudge = ifelse(implement_both.1 == 1, "Tax",
                                            ifelse(implement_both.1 == 2,
                                                   "Nudge",
                                            ifelse(implement_both.1 == 3,
                                                   "Both",
                                            ifelse(implement_both.1 == 4,
                                                   "Neither", NA)))),
                tax = ifelse(!is.na(implement_tax), implement_tax, implement_taxnudge),
                nudge = ifelse(!is.na(implement_nudge), implement_nudge, implement_taxnudge),
                support_tax = ifelse(tax %in% c("Tax", "Both"), 1, 0),
                support_nudge = ifelse(nudge %in% c("Nudge", "Both"), 1, 0),
                condition = ifelse(implement_both == 0,
                                   "Implement One",
                                   "Implement Both"),
                order = ifelse(nudge_first == 1, "Nudge First", "Tax First"),
                condition = ifelse(condition == "Implement Both",
                                   "Implement Both",
                                   ifelse(order == "Nudge First",
                                          "Implement Nudge First", "Implement Tax First")),
                condition = factor(condition, levels = c("Implement Tax First",
                                                         "Implement Both",
                                                         "Implement Nudge First"))) %>%
saveRDS(here::here("E:/Summer 2023/4. Impact Evaluation in Environmental Economics Using Field Experiments/Data/S2/study3A.Rds"))
