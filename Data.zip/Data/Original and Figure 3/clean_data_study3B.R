read.csv("E:/Summer 2023/4. Impact Evaluation in Environmental Economics Using Field Experiments/Data/S2/study3B_raw.csv",
         stringsAsFactors = F)[-1,-c(1:6)] %>%
  dplyr::filter(V10 == 1) %>%
  dplyr::select(-dplyr::contains("comments"),
                -dplyr::contains("intro"),
                -dplyr::contains("des"),
                -dplyr::contains("Location"),
                -V10,
                -receive_draft, -participate_research) %>%
  dplyr::mutate_at(dplyr::vars(-first_domain),
                   dplyr::funs(as.numeric)) %>%
  dplyr::mutate(id = seq(1:nrow(.)),
                policymaker = ifelse(impact_policy == 1 | inform_policy == 1,
                                     1, 0)) %>%
  tidyr::gather(question, implement, dplyr::contains("implement")) %>%
  dplyr::mutate(domain = ifelse(question == "retnudge_implement" | question == "rettax_implement",
                                "retirement", "environment"),
                policy = ifelse(question == "retnudge_implement" | question == "envnudge_implement",
                                "nudge", "tax"),
                domain_order = ifelse(domain == first_domain,
                                      "First Domain", "Second Domain"),
                nudge_first = ifelse(domain == "retirement",
                                     retirement_nudge_first, environment_nudge_first),
                policy_order = ifelse(nudge_first == 1, "Nudge First", "Tax First"),
                painful = ifelse(question == "retnudge_implement", retnudge_painful,
                                 ifelse(question == "rettax_implement", rettax_painful,
                                        ifelse(question == "envnudge_implement", envnudge_painful,
                                               envtax_painful))),
                effective = ifelse(question == "retnudge_implement", retnudge_effective,
                                   ifelse(question == "rettax_implement", rettax_effective,
                                          ifelse(question == "envnudge_implement", envnudge_effective,
                                                 envtax_effective)))) %>%
  dplyr::select(-dplyr::contains("_effective"),
                -dplyr::contains("_painful"),
                -environment_nudge_first,
                -retirement_nudge_first,
                -first_domain, -nudge_first) %>%
  saveRDS(here::here("E:/Summer 2023/4. Impact Evaluation in Environmental Economics Using Field Experiments/Data/S2/study3B.Rds"))
