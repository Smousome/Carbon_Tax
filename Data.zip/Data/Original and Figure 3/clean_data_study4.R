# Load the required libraries 'dplyr' and 'here'
library(dplyr)
library(here)

# Read the CSV file and perform data cleaning and manipulation
study4_data <- read.csv(here::here("E:/Summer 2023/4. Impact Evaluation in Environmental Economics Using Field Experiments/Data/S2/study4_raw.csv"), stringsAsFactors = FALSE) %>%
  select("V1", nudge_first,
         tax_attractive, nudge_ineffective,
         nudge_effective, nudge_painful,
         implement_nudge,
         tax_effective, tax_painful,
         Q33, gender, age, ethnicity,
         Q36,
         Q44, education, Q33.1, politics,
         Q32.2, Q33.2) %>%
  rename(id = "V1",
         implement_tax = Q33,
         view_climatechange = Q44,
         own_emissions = Q36) %>%
  mutate_at(dplyr::vars(-id, -Q32.2, -Q33.2), as.numeric) %>%
  mutate(condition = case_when(
    nudge_first == 0 ~ 'Tax First',
    nudge_first == 1 & tax_attractive == 0 & nudge_ineffective == 0 ~ 'Nudge First',
    tax_attractive == 1 ~ 'Tax Attractive',
    TRUE ~ 'Nudge Ineffective'
  ),
  condition = factor(condition, levels = c("Tax First", "Nudge First",
                                           "Nudge Ineffective",
                                           "Tax Attractive")),
  implement_nudge = recode(implement_nudge, `1` = 1, `2` = 0),
  implement_tax = recode(implement_tax, `1` = 1, `2` = 0),
  view_climatechange = recode(view_climatechange,
                              `1` = "Humans + Gov",
                              `2` = "Humans + No Gov",
                              `3` = "Nature + Gov",
                              `4` = "Nature + No Gov"),
  own_emissions = recode(own_emissions,
                         `1` = "Less Than Average",
                         `2` = "Average",
                         `3` = "More Than Average")
  ) %>%
  select(-nudge_first, -tax_attractive, -nudge_ineffective) %>%
  filter(grepl("pepper", Q32.2, ignore.case = TRUE) & grepl("August", Q33.2, ignore.case = TRUE))

# Save the cleaned and manipulated data as an RDS file
saveRDS(study4_data, file = here::here("E:/Summer 2023/4. Impact Evaluation in Environmental Economics Using Field Experiments/Data/S2/study4.Rds"))

