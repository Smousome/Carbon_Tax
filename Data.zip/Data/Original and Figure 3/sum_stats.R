# nudge painful
##########################################
install.packages("papaja")
install.packages("tinylabels")
install.packages("metafor")
install.packages("Matrix")
install.packages("metadat")
install.packages("numDeriv")
library("papaja")
library("tinylabels")
library("metafor")
install.packages("ggplot2")
library(ggplot2)
help(metafor)


study3B_firstdomain <- study3B %>%
  dplyr::filter(domain_order == "First Domain")
study3B_firstdomain_policymaker <- study3B %>%
  dplyr::filter(domain_order == "First Domain" & policymaker == 1)

nudge_pain <- list("1a" = study1A$nudge_painful,
                   "1bl" = study1B %>% dplyr::filter(pain == "Low Pain") %>% dplyr::select(nudge_painful),
                   "1bh" = study1B %>% dplyr::filter(pain == "High Pain") %>% dplyr::select(nudge_painful),
                   "2r" = study2 %>% dplyr::filter(related_nudge == "Related Nudge") %>% dplyr::select(Rnudge_painful),
                   "2u" = study2 %>% dplyr::filter(related_nudge == "Unrelated Nudge") %>% dplyr::select(Unudge_painful),
                   "3ar" = study3A %>% dplyr::filter(domain == "retirement") %>% dplyr::select(nudge_painful),
                   "3ae" = study3A %>% dplyr::filter(domain == "environment") %>% dplyr::select(nudge_painful),
                   "3be" = study3B %>% dplyr::filter(domain_order == "First Domain" & domain == "environment" & policy == "nudge") %>% dplyr::select(painful),
                   "3br" = study3B %>% dplyr::filter(domain_order == "First Domain" & domain == "retirement" & policy == "nudge") %>% dplyr::select(painful),
                   "4tf" = study4 %>% dplyr::filter(condition == "Tax First") %>% dplyr::select(nudge_painful),
                   "4nf" = study4 %>% dplyr::filter(condition == "Nudge First") %>% dplyr::select(nudge_painful),
                   "4ni" = study4 %>% dplyr::filter(condition == "Nudge Ineffective") %>% dplyr::select(nudge_painful),
                   "4ta" = study4 %>% dplyr::filter(condition == "Tax Attractive") %>% dplyr::select(nudge_painful)
                   )




# policy painful
################################################

policy_pain <- list("1a" = study1A$policy_painful,
                    "1bl" = study1B %>% dplyr::filter(pain == "Low Pain") %>% dplyr::select(policy_painful),
                    "1bh" = study1B %>% dplyr::filter(pain == "High Pain") %>% dplyr::select(policy_painful),
                    "2r" = study2 %>% dplyr::filter(related_nudge == "Related Nudge") %>% dplyr::select(policy_painful),
                    "2u" = study2 %>% dplyr::filter(related_nudge == "Unrelated Nudge") %>% dplyr::select(policy_painful),
                    "3ar" = study3A %>% dplyr::filter(domain == "retirement") %>% dplyr::select(tax_painful),
                    "3ae" = study3A %>% dplyr::filter(domain == "environment") %>% dplyr::select(tax_painful),
                    "3be" = study3B %>% dplyr::filter(domain_order == "First Domain" & domain == "environment" & policy == "tax") %>% dplyr::select(painful),
                    "3br" = study3B %>% dplyr::filter(domain_order == "First Domain" & domain == "retirement" & policy == "tax") %>% dplyr::select(painful),
                    "4tf" = study4 %>% dplyr::filter(condition == "Tax First") %>% dplyr::select(tax_painful),
                    "4nf" = study4 %>% dplyr::filter(condition == "Nudge First") %>% dplyr::select(tax_painful),
                    "4ni" = study4 %>% dplyr::filter(condition == "Nudge Ineffective") %>% dplyr::select(tax_painful),
                    "4ta" = study4 %>% dplyr::filter(condition == "Tax Attractive") %>% dplyr::select(tax_painful)
                    )

# nudge effective
################################################

nudge_effect <- list("1a" = study1A$nudge_effective,
                     "1bl" = study1B %>% dplyr::filter(pain == "Low Pain") %>% dplyr::select(nudge_effective),
                     "1bh" = study1B %>% dplyr::filter(pain == "High Pain") %>% dplyr::select(nudge_effective),
                     "2r" = study2 %>% dplyr::filter(related_nudge == "Related Nudge") %>% dplyr::select(Rnudge_effective),
                     "2u" = study2 %>% dplyr::filter(related_nudge == "Unrelated Nudge") %>% dplyr::select(Unudge_effective),
                     "3ar" = study3A %>% dplyr::filter(domain == "retirement") %>% dplyr::select(nudge_effective),
                     "3ae" = study3A %>% dplyr::filter(domain == "environment") %>% dplyr::select(nudge_effective),
                     "3be" = study3B %>% dplyr::filter(domain_order == "First Domain" & domain == "environment" & policy == "nudge") %>% dplyr::select(effective),
                     "3br" = study3B %>% dplyr::filter(domain_order == "First Domain" & domain == "retirement" & policy == "nudge") %>% dplyr::select(effective),
                     "4tf" = study4 %>% dplyr::filter(condition == "Tax First") %>% dplyr::select(nudge_effective),
                     "4nf" = study4 %>% dplyr::filter(condition == "Nudge First") %>% dplyr::select(nudge_effective),
                     "4ni" = study4 %>% dplyr::filter(condition == "Nudge Ineffective") %>% dplyr::select(nudge_effective),
                     "4ta" = study4 %>% dplyr::filter(condition == "Tax Attractive") %>% dplyr::select(nudge_effective)
                     )




# policy effective
################################################

policy_effect <- list("1a" = study1A$policy_effective,
                      "1bl" = study1B %>% dplyr::filter(pain == "Low Pain") %>% dplyr::select(policy_effective),
                      "1bh" = study1B %>% dplyr::filter(pain == "High Pain") %>% dplyr::select(policy_effective),
                      "2r" = study2 %>% dplyr::filter(related_nudge == "Related Nudge") %>% dplyr::select(policy_effective),
                      "2u" = study2 %>% dplyr::filter(related_nudge == "Unrelated Nudge") %>% dplyr::select(policy_effective),
                      "3ar" = study3A %>% dplyr::filter(domain == "retirement") %>% dplyr::select(tax_effective),
                      "3ae" = study3A %>% dplyr::filter(domain == "environment") %>% dplyr::select(tax_effective),
                      "3be" = study3B %>% dplyr::filter(domain_order == "First Domain" & domain == "environment" & policy == "tax") %>% dplyr::select(effective),
                      "3br" = study3B %>% dplyr::filter(domain_order == "First Domain" & domain == "retirement" & policy == "tax") %>% dplyr::select(effective),
                      "4tf" = study4 %>% dplyr::filter(condition == "Tax First") %>% dplyr::select(tax_effective),
                      "4nf" = study4 %>% dplyr::filter(condition == "Nudge First") %>% dplyr::select(tax_effective),
                      "4ni" = study4 %>% dplyr::filter(condition == "Nudge Ineffective") %>% dplyr::select(tax_effective),
                      "4ta" = study4 %>% dplyr::filter(condition == "Tax Attractive") %>% dplyr::select(tax_effective)
                      )


## study 3b

#######################################

# creating function
# to interleave the two vectors (mean and sd)

riffle <- function (a) {
  n <- min(length(a$mean),length(a$sd))
  p1 <- as.vector(rbind(a$mean[1:n],a$sd[1:n]))
  p2 <- c(a$mean[-(1:n)],a$sd[-(1:n)])
  c(p1,p2)
}

sumstat <- function(x) {

  data.frame(mean=lapply(x, function(x)
    mean(as.matrix(x), na.rm =T)) %>% unlist(),
    sd = lapply(x, function(x) sd(as.matrix(x), na.rm =T)) %>%
      unlist()) %>% riffle()

}

# results of t-tests

p.val <- function(x, y) {

  sapply(1:length(x),
         function(i) t.test(x[[i]], y[[i]])$p.value) %>%
    rbind(p = ., x = NA) %>% c()

}

# effect size

es <- function(x, y) {
  x = as.numeric(as.matrix(x))
  y = as.numeric(as.matrix(y))
  abs((mean(x) - mean(y)))/
    sqrt( ((length(x) - 1)*var(x) +
             (length(y) - 1)*var(y))/
            (length(x) + length(y) - 2)) %>%
    return()
}


effect_size <- function(x, y) {

  sapply(1:length(x),
         function(i) es(x[[i]], y[[i]])) %>%
    rbind(d = ., x = NA) %>% c()}


stat_tab <- cbind(sumstat(nudge_pain) %>% papaja::printnum(na_string = ""),
                  sumstat(policy_pain) %>% papaja::printnum(na_string = ""),
                  p.val(nudge_pain, policy_pain) %>% sapply(function(x) if(!is.na(x)){papaja::printp(x)} else{''}) %>% unlist(),
                  effect_size(nudge_pain, policy_pain) %>% papaja::printnum(na_string = ""),
                  sumstat(nudge_effect) %>% papaja::printnum(na_string = ""),
                  sumstat(policy_effect) %>% papaja::printnum(na_string = ""),
                  p.val(nudge_effect, policy_effect) %>% sapply(function(x) if(!is.na(x)){papaja::printp(x)} else{''}) %>% unlist(),
                  effect_size(nudge_effect, policy_effect) %>% papaja::printnum(na_string = "")) %>%
  as.data.frame() %>%
  dplyr::mutate(Study = c("Study 1A", "", "Study 1B", "", "", "",
                          "Study 2", "", "", "",
                          "Study 3A", "", "", "",
                          "Study 3B", "", "", "",
                          "Study 4", "", "", "", "", "", "", ""),
                x =     c("", "", "Low Pain", "", "High Pain", "",
                          "Related", "", "Unrelated", "",
                          "Retirement", "", "Environment", "", "Retirement", "", "Environment", "",
                          "Tax First", "", "Nudge First", "", "Nudge Ineffective", "", "Tax Attractive", "")) %>%
  dplyr::select(Study, x, dplyr::everything()) %>%
  setNames(., c("Study", "", "Nudge", "Tax", "p-value", "Cohen's d",
                "Nudge", "Tax", "p-value", "Cohen's d"))

stat_tab[is.na(stat_tab)] <- ""





########################


# Study 4 (study4 table)


# summary statistics for mechanism study

#############################


nudge_support <- list(
  "1at" = NA,
  "1atn" = study1A %>% dplyr::filter(tax_nudge_condition == 1) %$% papaja::printnum(mean(implement_taxnudge %in% c("Nudge", "Both"))*100),
  "1ap" = NA,
  "1ad" = NA,

  "1blt" = NA,
  "1bltn" = study1B %>% dplyr::filter(pain == "Low Pain" & condition == "Tax + Nudge") %$% papaja::printnum(mean(support_nudge==1)*100),
  "1blp" = NA,
  "1bld" = NA,

  "1bht" = NA,
  "1bhtn" = study1B %>% dplyr::filter(pain == "High Pain" & condition == "Tax + Nudge") %$% papaja::printnum(mean(support_nudge==1)*100),
  "1bhp" = NA,
  "1bhd" = NA,

  "2rt" = NA,
  "2rtn" = study2 %>% dplyr::filter(related_nudge == "Related Nudge" & condition == "Tax + Nudge") %$%
    papaja::printnum(mean(tax %in% c("Both", "Nudge"))*100),
  "2rp" = NA,
  "2rd" = NA,

  "2ut" = NA,
  "2utn" = study2 %>% dplyr::filter(related_nudge == "Unrelated Nudge" & condition == "Tax + Nudge") %$%
    papaja::printnum(mean(tax %in% c("Both", "Nudge"))*100),
  "2up" = NA,
  "2ud" = NA,

  "3aet" = study3A %>% dplyr::filter(domain == "environment" & condition == "Implement Tax First") %$%
    papaja::printnum(mean(support_nudge == 1)*100),
  "3aen" = study3A %>% dplyr::filter(domain == "environment" & condition == "Implement Nudge First") %$%
    papaja::printnum(mean(support_nudge == 1)*100),
  "3aep" = study3A %>% dplyr::filter(domain == "environment") %>%
              dplyr::filter(condition %in% c("Implement Tax First", "Implement Nudge First")) %$%
              t.test(support_nudge ~ condition)$p.val %>% papaja::printp(),
  "3aed" = study3A %>% dplyr::filter(domain == "environment") %$%
                                es(support_nudge[condition == "Implement Tax First"],
                                   support_nudge[condition == "Implement Nudge First"]) %>% papaja::printnum(),
  "3aeb" = study3A %>% dplyr::filter(domain == "environment" & condition == "Implement Both") %$%
    papaja::printnum(mean(support_nudge == 1)*100),
  "3aep" = study3A %>% dplyr::filter(domain == "environment") %>%
              dplyr::filter(condition %in% c("Implement Tax First", "Implement Both")) %$%
              t.test(support_nudge ~ condition)$p.val %>% papaja::printp(),
  "3aed" = study3A %>% dplyr::filter(domain == "environment") %$%
                                es(support_nudge[condition == "Implement Tax First"],
                                  support_nudge[condition == "Implement Both"]) %>% papaja::printnum(),


  "3art" = study3A %>% dplyr::filter(domain == "retirement" & condition == "Implement Tax First") %$%
    papaja::printnum(mean(support_nudge == 1)*100),
  "3arn" = study3A %>% dplyr::filter(domain == "retirement" & condition == "Implement Nudge First") %$%
    papaja::printnum(mean(support_nudge == 1)*100),
   "3arp" = study3A %>% dplyr::filter(domain == "retirement") %>%
              dplyr::filter(condition %in% c("Implement Tax First", "Implement Nudge First")) %$%
              t.test(support_nudge ~ condition)$p.val %>% papaja::printp(),
   "3aed" = study3A %>% dplyr::filter(domain == "retirement") %$%
                                es(support_nudge[condition == "Implement Tax First"],
                                  support_nudge[condition == "Implement Nudge First"]) %>% papaja::printnum(),
  "3arb" = study3A %>% dplyr::filter(domain == "retirement" & condition == "Implement Both") %$%
    papaja::printnum(mean(support_nudge == 1)*100),
  "3arp" = study3A %>% dplyr::filter(domain == "environment") %>%
              dplyr::filter(condition %in% c("Implement Tax First", "Implement Both")) %$%
              t.test(support_nudge ~ condition)$p.val %>% papaja::printp(),
  "3ard" = study3A %>% dplyr::filter(domain == "retirement") %$%
                                es(support_nudge[condition == "Implement Tax First"],
                                  support_nudge[condition == "Implement Both"]) %>% papaja::printnum(),
  "3bet" = study3B_firstdomain %>% dplyr::filter(domain == "environment" &
                                                   policy_order == "Tax First" & policy == "nudge") %$%
    papaja::printnum(mean(implement)*100),
  "3ben" = study3B_firstdomain %>% dplyr::filter(domain == "environment" &
                                                   policy_order == "Nudge First" & policy == "nudge") %$%
    papaja::printnum(mean(implement)*100),
  "3bep" = study3B_firstdomain %>% dplyr::filter(domain == "environment" & policy == "nudge") %$%
    t.test(implement ~ policy_order)$p.val %>% papaja::printp(),
  "3bed" = study3B_firstdomain %>% dplyr::filter(domain == "environment" & policy == "nudge") %$%
    es(implement[policy_order == "Nudge First"], implement[policy_order == "Tax First"]) %>% papaja::printnum(),


  "3brt" = study3B_firstdomain %>% dplyr::filter(domain == "retirement" &
                                                   policy_order == "Tax First" & policy == "nudge") %$%
    papaja::printnum(mean(implement)*100),
  "3brn" = study3B_firstdomain %>% dplyr::filter(domain == "retirement" &
                                                   policy_order == "Nudge First" & policy == "nudge") %$%
    papaja::printnum(mean(implement)*100),
  "3brp" = study3B_firstdomain %>% dplyr::filter(domain == "retirement" & policy == "nudge") %$%
    t.test(implement ~ policy_order)$p.val %>% papaja::printp(),
  "3brd" = study3B_firstdomain %>% dplyr::filter(domain == "retirement" & policy == "nudge") %$%
    es(implement[policy_order == "Nudge First"], implement[policy_order == "Tax First"]) %>% papaja::printnum(),

  #####################
  "4nf" = study4 %>% dplyr::filter(condition == "Nudge First") %$% papaja::printnum(mean(implement_nudge==1)*100),
  "4tf" = study4 %>% dplyr::filter(condition == "Tax First") %$% papaja::printnum(mean(implement_nudge==1)*100),
  "41p" = study4 %>% dplyr::filter(condition %in% c("Nudge First", "Tax First")) %$%
    t.test(implement_nudge ~ condition)$p.val %>% papaja::printp(),
  "41d" = study4 %>% dplyr::filter(condition %in% c("Tax First", "Nudge First")) %$%
    es(implement_nudge[condition == "Tax First"], implement_nudge[condition == "Nudge First"]) %>% papaja::printnum(),

  "4ta" = study4 %>% dplyr::filter(condition == "Tax Attractive") %$% papaja::printnum(mean(implement_nudge==1)*100),
  "42p" = study4 %>% dplyr::filter(condition %in% c("Nudge First", "Tax Attractive")) %$%
    t.test(implement_nudge ~ condition)$p.val %>% papaja::printp(),
  "42d" = study4 %>% dplyr::filter(condition %in% c("Tax Attractive", "Nudge First")) %$%
    es(implement_nudge[condition == "Tax Attractive"], implement_nudge[condition == "Nudge First"]) %>% papaja::printnum(),


  "4ni" = study4 %>% dplyr::filter(condition == "Nudge Ineffective") %$% papaja::printnum(mean(implement_nudge==1)*100),
  "43p" = study4 %>% dplyr::filter(condition %in% c("Nudge First", "Nudge Ineffective")) %$%
    t.test(implement_nudge ~ condition)$p.val %>% papaja::printp(),
  "43d" = study4 %>% dplyr::filter(condition %in% c("Nudge Ineffective", "Nudge First")) %$%
    es(implement_nudge[condition == "Nudge Ineffective"], implement_nudge[condition == "Nudge First"]) %>% papaja::printnum()
  )




# policy support
################################################

policy_support <- list(
  "1at" = study1A %>% dplyr::filter(tax_nudge_condition == 0) %$% papaja::printnum(mean(support_tax==1)*100),
  "1atn" = study1A %>% dplyr::filter(tax_nudge_condition == 1) %$% papaja::printnum(mean(support_tax==1)*100),
  "1ap" = study1A %$% t.test(support_tax ~ tax_nudge_condition)$p.val %>% papaja::printp(),
  "1ad" = study1A %$% es(support_tax[tax_nudge_condition==1], support_tax[tax_nudge_condition==0]) %>% papaja::printnum(),

  "1blt" = study1B %>% dplyr::filter(pain == "Low Pain" & condition == "Tax Only") %$% papaja::printnum(mean(support_tax==1)*100),
  "1bltn" = study1B %>% dplyr::filter(pain == "Low Pain" & condition == "Tax + Nudge") %$% papaja::printnum(mean(support_tax==1)*100),
  "1blp" = study1B %>%  dplyr::filter(pain == "Low Pain") %$% t.test(support_tax ~ condition)$p.val %>% papaja::printp(),
  "1bld" = study1B %>% dplyr::filter(pain == "Low Pain") %$% es(support_tax[condition == "Tax Only"], support_tax[condition == "Tax + Nudge"]) %>% papaja::printnum(),


  "1bht" = study1B %>% dplyr::filter(pain == "High Pain" & condition == "Tax Only") %$% papaja::printnum(mean(support_tax==1)*100),
  "1bhtn" = study1B %>% dplyr::filter(pain == "High Pain" & condition == "Tax + Nudge") %$% papaja::printnum(mean(support_tax==1)*100),
  "1bhp" = study1B %>%  dplyr::filter(pain == "High Pain") %$% t.test(support_tax ~ condition)$p.val %>% papaja::printp(),
  "1bhd" = study1B %>% dplyr::filter(pain == "High Pain") %$% es(support_tax[condition == "Tax Only"], support_tax[condition == "Tax + Nudge"]) %>% papaja::printnum(),


  "2rt" = study2 %>% dplyr::filter(related_nudge == "Related Nudge" & condition == "Tax Only") %$%
    papaja::printnum(mean(support_tax == 1)*100),
  "2rtn" = study2 %>% dplyr::filter(related_nudge == "Related Nudge" & condition == "Tax + Nudge") %$%
    papaja::printnum(mean(support_tax == 1)*100),
  "2rp" = study2 %>%  dplyr::filter(related_nudge == "Related Nudge") %$% t.test(support_tax~condition)$p.val %>% papaja::printp(),
  "2rd" = study2 %>% dplyr::filter(related_nudge == "Related Nudge") %$%
    es(support_tax[condition == "Tax Only"], support_tax[condition == "Tax + Nudge"]) %>% papaja::printnum(),


  "2ut" = study2 %>% dplyr::filter(related_nudge == "Unrelated Nudge" & condition == "Tax Only") %$%
    papaja::printnum(mean(support_tax == 1)*100),
  "2utn" = study2 %>% dplyr::filter(related_nudge == "Unrelated Nudge" & condition == "Tax + Nudge") %$%
    papaja::printnum(mean(support_tax == 1)*100),
  "2up" = study2 %>%  dplyr::filter(related_nudge == "Unrelated Nudge") %$% t.test(support_tax~condition)$p.val %>% papaja::printp(),
  "2ud" =  study2 %>% dplyr::filter(related_nudge == "Unrelated Nudge") %$%
    es(support_tax[condition == "Tax Only"], support_tax[condition == "Tax + Nudge"]) %>% papaja::printnum(),

  "3aet" = study3A %>% dplyr::filter(domain == "environment" & condition == "Implement Tax First") %$%
    papaja::printnum(mean(support_tax == 1)*100),
  "3aen" = study3A %>% dplyr::filter(domain == "environment" & condition == "Implement Nudge First") %$%
    papaja::printnum(mean(support_tax == 1)*100),
  "3aep" = study3A %>% dplyr::filter(domain == "environment") %>%
              dplyr::filter(condition %in% c("Implement Tax First", "Implement Nudge First")) %$%
              t.test(support_tax ~ condition)$p.val %>% papaja::printp(),
  "3aed" = study3A %>% dplyr::filter(domain == "environment") %$%
                                es(support_tax[condition == "Implement Tax First"],
                                  support_tax[condition == "Implement Nudge First"]) %>% papaja::printnum(),
  "3aeb" = study3A %>% dplyr::filter(domain == "environment" & condition == "Implement Both") %$%
    papaja::printnum(mean(support_tax == 1)*100),
  "3aep" = study3A %>% dplyr::filter(domain == "environment") %>%
              dplyr::filter(condition %in% c("Implement Tax First", "Implement Both")) %$%
              t.test(support_tax ~ condition)$p.val %>% papaja::printp(),
  "3aed" = study3A %>% dplyr::filter(domain == "environment") %$%
                                es(support_tax[condition == "Implement Tax First"],
                                  support_tax[condition == "Implement Both"]) %>% papaja::printnum(),


  "3art" = study3A %>% dplyr::filter(domain == "retirement" & condition == "Implement Tax First") %$%
    papaja::printnum(mean(support_tax == 1)*100),
  "3arn" = study3A %>% dplyr::filter(domain == "retirement" & condition == "Implement Nudge First") %$%
    papaja::printnum(mean(support_tax == 1)*100),
   "3arp" = study3A %>% dplyr::filter(domain == "retirement") %>%
              dplyr::filter(condition %in% c("Implement Tax First", "Implement Nudge First")) %$%
              t.test(support_tax ~ condition)$p.val %>% papaja::printp(),
   "3aed" = study3A %>% dplyr::filter(domain == "retirement") %$%
                                es(support_tax[condition == "Implement Tax First"],
                                  support_tax[condition == "Implement Nudge First"]) %>% papaja::printnum(),
  "3arb" = study3A %>% dplyr::filter(domain == "retirement" & condition == "Implement Both") %$%
    papaja::printnum(mean(support_tax == 1)*100),
  "3arp" = study3A %>% dplyr::filter(domain == "environment") %>%
              dplyr::filter(condition %in% c("Implement Tax First", "Implement Both")) %$%
              t.test(support_tax ~ condition)$p.val %>% papaja::printp(),
  "3ard" = study3A %>% dplyr::filter(domain == "retirement") %$%
                                es(support_tax[condition == "Implement Tax First"],
                                  support_tax[condition == "Implement Both"]) %>% papaja::printnum(),

  "3bet" = study3B_firstdomain_policymaker %>% dplyr::filter(domain == "environment" &
                                                               policy_order == "Tax First" & policy == "tax") %$%
    papaja::printnum(mean(implement)*100),
  "3ben" = study3B_firstdomain_policymaker %>% dplyr::filter(domain == "environment" &
                                                               policy_order == "Nudge First" & policy == "tax") %$%
    papaja::printnum(mean(implement)*100),
  "3bep" = study3B_firstdomain_policymaker %>% dplyr::filter(domain == "environment" & policy == "tax") %$%
    t.test(implement ~ policy_order)$p.val %>% papaja::printp(),
  "3bed" = study3B_firstdomain_policymaker %>% dplyr::filter(domain == "environment" & policy == "tax") %$%
    es(implement[policy_order == "Nudge First"], implement[policy_order == "Tax First"]) %>% papaja::printnum(),

  "3brt" = study3B_firstdomain_policymaker %>% dplyr::filter(domain == "retirement" &
                                                               policy_order == "Tax First" & policy == "tax") %$%
    papaja::printnum(mean(implement)*100),
  "3brn" = study3B_firstdomain_policymaker %>% dplyr::filter(domain == "retirement" &
                                                               policy_order == "Nudge First" & policy == "tax") %$%
    papaja::printnum(mean(implement)*100),
  "3brp" = study3B_firstdomain_policymaker %>% dplyr::filter(domain == "retirement" & policy == "tax") %$%
    t.test(implement ~ policy_order)$p.val %>% papaja::printp(),
  "3brd" = study3B_firstdomain_policymaker %>% dplyr::filter(domain == "retirement" & policy == "tax") %$%
    es(implement[policy_order == "Nudge First"], implement[policy_order == "Tax First"]) %>% papaja::printnum(),

  #####################
  "4nf" = study4 %>% dplyr::filter(condition == "Nudge First") %$% papaja::printnum(mean(implement_tax==1)*100),
  "4tf" = study4 %>% dplyr::filter(condition == "Tax First") %$% papaja::printnum(mean(implement_tax==1)*100),
  "41p" = study4 %>% dplyr::filter(condition %in% c("Nudge First", "Tax First")) %$%
    t.test(implement_tax ~ condition)$p.val %>% papaja::printp(),
  "41d" = study4 %>% dplyr::filter(condition %in% c("Tax First", "Nudge First")) %$%
    es(implement_tax[condition == "Tax First"], implement_tax[condition == "Nudge First"]) %>% papaja::printnum(),

  "4ta" = study4 %>% dplyr::filter(condition == "Tax Attractive") %$% papaja::printnum(mean(implement_tax==1)*100),
  "42p" = study4 %>% dplyr::filter(condition %in% c("Nudge First", "Tax Attractive")) %$%
    t.test(implement_tax ~ condition)$p.val %>% papaja::printp(),
  "42d" = study4 %>% dplyr::filter(condition %in% c("Tax Attractive", "Nudge First")) %$%
    es(implement_tax[condition == "Tax Attractive"], implement_tax[condition == "Nudge First"]) %>% papaja::printnum(),

  "4ni" = study4 %>% dplyr::filter(condition == "Nudge Ineffective") %$% papaja::printnum(mean(implement_tax==1)*100),
  "43p" = study4 %>% dplyr::filter(condition %in% c("Nudge First", "Nudge Ineffective")) %$%
    t.test(implement_tax ~ condition)$p.val %>% papaja::printp(),
  "43d" = study4 %>% dplyr::filter(condition %in% c("Nudge Ineffective", "Nudge First")) %$%
    es(implement_tax[condition == "Nudge Ineffective"], implement_tax[condition == "Nudge First"]) %>% papaja::printnum()
  )

# effect size: if t.test, then d, if anova, then eta


sumstat_support <- cbind(policy_support, nudge_support) %>%
  as.data.frame() %>%
  dplyr::mutate(Study = c("Study 1A", "", "", "", "Study 1B", "", "", "", "", "","", "",
                          "Study 2", "", "", "", "", "", "", "",
                          "Study 3A", "", "", "", "", "", "", "", "", "", "", "", "", "",
                          "Study 3B", "", "", "", "", "", "", "",
                          "Study 4", "", "", "", "", "", "", "", "", ""),
                condition =     c("Tax", "Tax + Nudge", "p", "Cohen's d",
                                  "Low Pain - Tax", "Low Pain - Tax + Nudge", "p", "Cohen's d",
                                  "High Pain - Tax", "High Pain - Tax + Nudge", "p", "Cohen's d",
                                  "Related Nudge - Tax", "Related Nudge - Tax + Nudge", "p", "Cohen's d",
                                  "Unrelated Nudge - Tax", "Unrelated Nudge - Tax + Nudge", "p", "Cohen's d",

                                  "Environment - Tax First", "Environment - Nudge First", "p", "Cohen's d",
                                  "Environment - Tax + Nudge", "p", "Cohen's d",
                                  "Retirement - Tax First", "Retirement - Nudge First", "p", "Cohen's d",
                                  "Retirement - Tax + Nudge", "p", "Cohen's d",
                                  "Environment - Tax First", "Environment - Nudge First", "p", "Cohen's d",
                                  "Retirement - Tax First", "Retirement - Nudge First", "p", "Cohen's d",
                                  "Nudge First", "Tax First", "p", "Cohen's d",
                                  "Tax Attractive", "p", "Cohen's d",
                                  "Nudge Ineffective", "p", "Cohen's d")) %>%
  dplyr::select(Study, condition, dplyr::everything()) %>%
  setNames(., c("", "", "Support Tax", "Support Nudge"))

sumstat_support[is.na(sumstat_support)] <- ""

############################
# meta-analysis
#Variance of d formula (Cooper, Harris, Hedges, "Handbook of Research Synthesis 1993", p.238)

vard=function(d,n) (2/n+(d^2)/(2*(2*n-2)))*((2*n)/(2*n-2))

meta_dat <- data.frame(study = c("1a", "1b", "2", "3a_1", "3a_2", "3b", "4"),
                       d = c(study1A %$% es(support_tax[tax_nudge_condition==1], support_tax[tax_nudge_condition==0]),
                             study1B %$% es(support_tax[condition == "Tax Only"], support_tax[condition == "Tax + Nudge"]),
                             study2 %>% dplyr::filter(related_nudge == "Related Nudge") %$%
                               es(support_tax[condition == "Tax Only"], support_tax[condition == "Tax + Nudge"]),
                             study3A %>% dplyr::filter(condition != "Implement Both" & domain == "environment") %$%
                               es(support_tax[condition == "Implement Tax First"], support_tax[condition == "Implement Nudge First"]),
                             study3A %>% dplyr::filter(condition != "Implement Nudge First" & domain == "environment") %$%
                               es(support_tax[condition == "Implement Tax First"], support_tax[condition == "Implement Both"]),
                             study3B %>% dplyr::filter(domain_order == "First Domain" & domain == "environment" & policy == "tax") %$%
                               es(implement[policy_order == "Nudge First"], implement[policy_order == "Tax First"]),
                             study4 %>% dplyr::filter(condition %in% c("Tax First", "Nudge First")) %$%
                               es(implement_tax[condition == "Tax First"], implement_tax[condition == "Nudge First"]) ),
                       n = c(nrow(study1A), nrow(study1B),
                             nrow(study2 %>% dplyr::filter(related_nudge == "Related Nudge")),
                             nrow(study3A %>% dplyr::filter(condition != "Implement Both" & domain == "environment")),
                             nrow(study3A %>% dplyr::filter(condition != "Implement Nudge First" & domain == "environment")),
                             nrow(study3B %>% dplyr::filter(domain_order == "First Domain" & domain == "environment" & policy == "tax")),
                             nrow(study4 %>% dplyr::filter(condition %in% c("Tax First", "Nudge First"))))) %>%
  dplyr::mutate(v = vard(d, n))

meta_result <- metafor::rma(yi = d, vi = v, method = "ML", data = meta_dat)

########

# Sample data
set.seed(123)
percentiles <- seq(10, 90, 10)
information <- c("Low", "Medium", "High")
crowd_out_nudge <- c(10, 20, 15, 25, 30, 22, 18, 8, 5)
crowd_out_tax <- c(15, 25, 20, 30, 35, 28, 22, 12, 8)

# data frame
data <- data.frame(Percentile = rep(percentiles, length(information)),
                   Information = factor(rep(information, each = length(percentiles))),
                   Policy = factor(rep(c("Nudge", "Tax"), each = length(percentiles) * length(information))),
                   Crowd_Out = c(crowd_out_nudge, crowd_out_tax))

# Plotting the bar graph
ggplot(data, aes(x = paste(Percentile, "%"), y = Crowd_Out, fill = Information)) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.8), width = 0.6) +
  facet_wrap(~Policy, ncol = 1) +
  xlab("Percentile of Participation") +
  ylab("Crowd-out Percentage") +
  labs(fill = "Information Provision") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  scale_fill_manual(values = c("black", "mistyrose4", "azure4"),
                    labels = c("Low", "Medium", "High"))






