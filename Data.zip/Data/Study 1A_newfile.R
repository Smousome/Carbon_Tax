# Load libraries
library(ggplot2)
library(dplyr)

# Read the RDS file
survey_data <- read.csv("E:/Summer 2023/4. Impact Evaluation in Environmental Economics Using Field Experiments/Data/S1/study1A.Rds")

study1A <- readRDS("E:/Summer 2023/4. Impact Evaluation in Environmental Economics Using Field Experiments/Data/S1/study1A.Rds")

# Converting the "nudge_effective" and "Policy_effective" variable to a factor with ordered levels
study1A$nudge_effective <- factor(study1A$nudge_effective,
                                  levels = c(1, 2, 3, 4, 5),
                                  labels = c("1", "2", "3", "4", "5"))

study1A$policy_effective <- factor(study1A$policy_effective,
                                   levels = c(1, 2, 3, 4, 5),
                                   labels = c("1", "2", "3", "4", "5"))

# Calculation of the responses percentage for each rating category
nudge_summary <- study1A %>%
  group_by(nudge_effective) %>%
  summarise(count = n(),
            percentage = n() / nrow(study1A) * 100)

policy_summary <- study1A %>%
  group_by(policy_effective) %>%
  summarise(count = n(),
            percentage = n() / nrow(study1A) * 100)

# updated "nudge_effective" and "policy_effective" to numeric
study1A$nudge_effective <- as.numeric(as.character(study1A$nudge_effective))
study1A$policy_effective <- as.numeric(as.character(study1A$policy_effective))


#Combine data for "nudge_effective" and "policy_effective" into a single data frame
combined_data <- rbind(
  data.frame(intervention = "Nudge", response = study1A$nudge_effective),
  data.frame(intervention = "Policy", response = study1A$policy_effective)
)


#grouped bar plot
ggplot(combined_data, aes(x = factor(response), fill = intervention)) +
  geom_bar(position = "dodge") +
  labs(title = "Comparison of Nudge and Policy Effectiveness by Response Scale",
       x = "Rating of response",
       y = "Count of acceptance of nudge and Carbon tax") +
  scale_fill_manual(values = c("black", "darkgrey"),
                    labels = c("Tax+Nudge", "Carbon Tax")) +
  scale_y_continuous(breaks = seq(0, 100, by = 5)) +
  theme_minimal() +
  theme(legend.title = element_blank())

# Calculation of confidence intervals for "nudge_effective" and "policy_effective"
conf_interval_nudge <- t.test(study1A$nudge_effective)$conf.int
conf_interval_policy <- t.test(study1A$policy_effective)$conf.int

#results of CI
cat("Confidence Interval for Nudge Effectiveness:", conf_interval_nudge, "\n")
cat("Confidence Interval for Policy Effectiveness:", conf_interval_policy, "\n")

# two-sample t-test to compare "nudge_effective" and "policy_effective"
t_test_result <- t.test(study1A$nudge_effective, study1A$policy_effective)


# p-value and Cohen's d effect size
p_value <- t_test$p.value

cohen_d <- abs((mean(study1A$nudge_effective) - mean(study1A$policy_effective)) / 
                 sqrt((var(study1A$nudge_effective) + var(study1A$policy_effective)) / 2))
# results
cat("P-value:", p_value, "\n")
cat("Cohen's d:", cohen_d, "\n")