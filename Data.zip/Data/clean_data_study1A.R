read.csv(here::here("inst/ext/Study1A_raw.csv"),
               stringsAsFactors = F)[-1,-c(1:7)] %>%
  dplyr::filter(V10 == 1) %>%
  dplyr::select(-dplyr::contains("comments"),
                -dplyr::contains("intro"),
                -dplyr::contains("description"),
                -V10, -Q26, -Q28) %>%
  dplyr::mutate_all(dplyr::funs(as.numeric)) %>%
  dplyr::mutate(male = ifelse(gender == 1, 1, 0)) %>%
  dplyr::select(-gender) %>%
  dplyr::mutate(implement_tax = ifelse(implement_tax == 1, "Tax",
                                        ifelse(implement_tax == 2, "NoTax", NA)),
                implement_taxnudge = ifelse(implement_taxnudge == 1, "Tax",
                                            ifelse(implement_taxnudge == 2,
                                                   "Nudge",
                                            ifelse(implement_taxnudge == 3,
                                                   "Both",
                                            ifelse(implement_taxnudge == 4,
                                                   "Neither", NA)      ))),
                tax = ifelse(!is.na(implement_tax), implement_tax, implement_taxnudge),
                support_tax = ifelse(tax %in% c("Tax", "Both"), 1, 0),
                tax_nudge_condition = ifelse(policy_only == 1, 0,1)) %>%
  saveRDS(here::here("data/study1A.Rds"))
